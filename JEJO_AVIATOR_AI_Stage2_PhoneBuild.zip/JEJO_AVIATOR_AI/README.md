# JEJO AVIATOR AI (Android)

An Android app for recording completed multipliers, retaining history locally, and displaying descriptive statistics.

## Requirements
- Android Studio (free)
- JDK 17 (Android Studio can install/use its bundled JDK)
- Android SDK Platform 35
- Internet connection for Gradle dependency downloads

## Open and run
1. Download and extract `JEJO_AVIATOR_AI.zip`.
2. Open Android Studio.
3. Choose **Open** and select the extracted `JEJO_AVIATOR_AI` folder.
4. Allow Gradle sync to finish.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Press **Run**.

## Build an APK
In Android Studio select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The debug APK is normally created at:
`app/build/outputs/apk/debug/app-debug.apk`

## Data connection status
The app currently works with manual round entry. Completed rounds are saved locally on the device (up to 5,000 records). There is intentionally no fake live feed.

## Current Stage 2 improvements
- Local persistence for round history using Android SharedPreferences
- Input state survives basic UI recomposition
- Provider integration contract placeholder in `AuthorizedFeedContract.kt`
- Explicitly reports that no official feed is connected
An official feed can only be connected after you obtain:
- Written authorization for your intended use
- Official API documentation and base URL
- Authentication/signature requirements
- Permitted data fields and polling/websocket rules
- Test credentials and production access approval

Implement the provider-specific adapter on a secure backend. The Android app must call your backend over HTTPS. Do not place provider API keys or signing secrets in the APK.

## Important
- This is an independent analytics utility, not an official SPRIBE product.
- Historical outcomes do not reliably predict future rounds.
- It does not place bets, log into betting accounts, or guarantee profits.
- Check applicable Kenyan laws and platform terms before using a gambling-related service.


## Build from an Android phone (GitHub Actions)
This project includes `.github/workflows/build-android.yml` so you can trigger a cloud build from Chrome without installing Android Studio.

1. Create/sign in to a GitHub account in Chrome.
2. Create a new repository named `JEJO-AVIATOR-AI`. A public repository avoids using private-repository Actions minutes; do not upload secrets.
3. Extract this ZIP on your phone.
4. Upload the project files and folders to the repository root, including the hidden `.github` folder and workflow file. If GitHub's mobile upload flow hides dot-folders, use GitHub's web desktop mode or add the workflow file through the repository's **Add file → Create new file** option at `.github/workflows/build-android.yml`.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab and select **Build JEJO AVIATOR AI APK**. Run workflow if it has not started automatically.
7. Open the completed workflow run, scroll to **Artifacts**, and download `JEJO-AVIATOR-AI-debug-apk`.
8. Extract the artifact ZIP and install `app-debug.apk` on your Android phone.

GitHub Actions availability and free usage limits depend on GitHub account and repository settings. Never add API keys or passwords to a public repository.
