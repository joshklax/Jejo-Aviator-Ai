package com.jejo.aviator

/**
 * Integration boundary for a provider-authorized feed.
 *
 * Do not guess endpoints, headers, signatures, or JSON fields.
 * Implement this interface only after the provider supplies written
 * authorization and its current API specification.
 */
data class ProviderRound(
    val providerRoundId: String,
    val multiplier: Double,
    val completedAtEpochMillis: Long
)

interface AuthorizedRoundFeed {
    suspend fun fetchLatestRounds(): List<ProviderRound>
}

/*
 * Recommended production architecture:
 *
 * Android app -> YOUR HTTPS backend -> provider-authorized API
 *
 * Keep provider credentials, signing secrets, and allowlisted IP
 * configuration on the backend. Never embed secrets in the APK.
 */
