package com.jejo.aviator

import android.os.Bundle
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Navy = Color(0xFF081522)
private val Panel = Color(0xFF122536)
private val Mint = Color(0xFF35D6A0)
private val Muted = Color(0xFF9BB0C0)

data class Round(val multiplier: Double, val time: Long = System.currentTimeMillis())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JejoApp() }
    }
}

@Composable
fun JejoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var input by rememberSaveable { mutableStateOf("") }
    val rounds = remember {
        mutableStateListOf<Round>().apply { addAll(loadRounds(context)) }
    }
    LaunchedEffect(rounds.toList()) {
        saveRounds(context, rounds.toList())
    }
    var tab by remember { mutableStateOf("Dashboard") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Mint,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Dashboard", "History", "About").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Text(when(item) { "Dashboard" -> "◉"; "History" -> "▤"; else -> "ⓘ" }) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                "Dashboard" -> Dashboard(
                    rounds = rounds, input = input, onInput = { input = it },
                    onAdd = {
                        val value = input.trim().replace(',', '.').toDoubleOrNull()
                        if (value != null && value >= 1.0 && value <= 1_000_000.0) {
                            rounds.add(0, Round(value))
                            input = ""
                        }
                    },
                    modifier = Modifier.padding(padding)
                )
                "History" -> History(rounds, onClear = { rounds.clear() }, modifier = Modifier.padding(padding))
                else -> About(modifier = Modifier.padding(padding))
            }
        }
    }
}


private fun loadRounds(context: Context): List<Round> {
    return try {
        val raw = context.getSharedPreferences("jejo_aviator", Context.MODE_PRIVATE)
            .getString("rounds", "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val multiplier = item.optDouble("multiplier", Double.NaN)
            val time = item.optLong("time", 0L)
            if (multiplier.isFinite() && multiplier >= 1.0) Round(multiplier, time) else null
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun saveRounds(context: Context, rounds: List<Round>) {
    val array = JSONArray()
    rounds.take(5000).forEach { round ->
        array.put(JSONObject().put("multiplier", round.multiplier).put("time", round.time))
    }
    context.getSharedPreferences("jejo_aviator", Context.MODE_PRIVATE)
        .edit().putString("rounds", array.toString()).apply()
}

@Composable
fun Dashboard(
    rounds: List<Round>, input: String, onInput: (String) -> Unit,
    onAdd: () -> Unit, modifier: Modifier = Modifier
) {
    val values = rounds.map { it.multiplier }
    val average = if (values.isEmpty()) 0.0 else values.average()
    val lowCount = values.count { it < 2.0 }
    val highCount = values.count { it >= 10.0 }
    val volatility = when {
        values.size < 5 -> "Not enough data"
        values.map { it }.let { list -> list.maxOrNull()!! - list.minOrNull()!! } >= 10 -> "High variation"
        else -> "Lower variation in sample"
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("JEJO", color = Mint, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("AVIATOR AI", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("ROUND ANALYSIS • NOT A WINNING SIGNAL", color = Muted, fontSize = 11.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("ROUND INPUT", color = Mint, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = input, onValueChange = onInput,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Enter multiplier (e.g. 2.45)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                    Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Add completed round")
                    }
                    Text("Manual entry is enabled until an authorized provider feed is configured.",
                        color = Muted, fontSize = 11.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("ROUNDS", "${values.size}", Modifier.weight(1f))
                MetricCard("AVERAGE", if (values.isEmpty()) "—" else String.format(Locale.US, "%.2fx", average), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("BELOW 2x", "$lowCount", Modifier.weight(1f))
                MetricCard("10x OR MORE", "$highCount", Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("SAMPLE VOLATILITY", color = Mint, fontWeight = FontWeight.Bold)
                    Text(volatility, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "This describes recorded history only. It does not predict the next crash point or change its odds.",
                        color = Muted, fontSize = 12.sp
                    )
                }
            }
        }
        item {
            Text("RECENT ROUNDS", color = Mint, fontWeight = FontWeight.Bold)
        }
        if (rounds.isEmpty()) {
            item { Text("No rounds recorded yet.", color = Muted) }
        } else {
            items(rounds.take(8)) { round ->
                Row(
                    Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Completed round")
                    Text(String.format(Locale.US, "%.2fx", round.multiplier), color = if (round.multiplier >= 2) Mint else Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, fontSize = 10.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun History(rounds: List<Round>, onClear: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("ROUND HISTORY", color = Mint, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${rounds.size} recorded rounds", color = Muted, modifier = Modifier.weight(1f))
            TextButton(onClick = onClear) {
                Icon(Icons.Default.Delete, contentDescription = null)
                Text(" Clear")
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rounds) { round ->
                Row(
                    Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Round")
                    Text(String.format(Locale.US, "%.2fx", round.multiplier), color = Mint, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun About(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ABOUT JEJO", color = Mint, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("JEJO AVIATOR AI is an independent statistics dashboard.")
        Text("It is not affiliated with or endorsed by SPRIBE.")
        Text("No system can reliably know future Aviator multipliers. Previous rounds do not guarantee future outcomes.")
        Text("Official integration status: Not connected. Add provider-approved API documentation and credentials on the backend before enabling a live feed.")
        Text("Never paste API secrets into the Android app.")
    }
}
